/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __ASM_GENERIC_CFI_H
#define __ASM_GENERIC_CFI_H

#endif /* __ASM_GENERIC_CFI_H */
